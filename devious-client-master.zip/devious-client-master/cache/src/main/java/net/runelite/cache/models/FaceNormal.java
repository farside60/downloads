package net.runelite.cache.models;

public class FaceNormal
{
	public int x;
	public int y;
	public int z;
}
